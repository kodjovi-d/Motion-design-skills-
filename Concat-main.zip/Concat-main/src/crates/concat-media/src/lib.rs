// SPDX-License-Identifier: AGPL-3.0-or-later
// SPDX-FileCopyrightText: 2026 Jareer Abdullah and Concat contributors

//! Media IO: reading frames and samples out of files and writing them back.
//!
//! This is the only crate that knows FFmpeg exists, and it links it -
//! libavformat, libavcodec, libavfilter, libswscale and libswresample -
//! rather than spawning the `ffmpeg` binary. Nothing here needs a program on
//! `PATH`; a build needs the FFmpeg development libraries, and the binary
//! carries the rest.
//!
//! Everything codec-shaped hides behind two traits, [`FrameSource`] and
//! [`FrameSink`]. A GPU-decode backend would implement those two and nothing
//! else in the workspace changes.

pub mod audio;
pub mod decode;
pub mod encode;
pub mod error;
mod feed;
mod ffi;
pub mod hardware;
pub mod peaks;
pub mod pool;
pub mod prefetch;
pub mod probe;
pub mod samples;
pub mod svg;
pub mod treat;

pub use decode::{ColorRange, ColorSignal, DecodeOptions, Decoder, FrameSource, SeekableSource};
pub use encode::{EncodeOptions, Encoder, FrameSink, RateMode, VideoCodec, jpeg};
pub use error::{Error, Result};
pub use ffi::{init, linked_version};
pub use hardware::{HwDevice, HwPolicy, hardware_decode, set_hardware_decode};
pub use peaks::{Peaks, Pyramid};
pub use pool::{CacheStats, FrameCache, FrameRequest, ReaderPool};
pub use prefetch::{Cursor, Direction, Moment, Prefetcher, Priority};
pub use probe::{AudioStream, MediaInfo, VideoStream, probe};
pub use samples::{AudioDecoder, AudioOptions, SampleFormat};
pub use treat::{fit, treat, treat_to};
