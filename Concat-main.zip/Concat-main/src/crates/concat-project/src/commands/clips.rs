// SPDX-License-Identifier: AGPL-3.0-or-later
// SPDX-FileCopyrightText: 2026 Jareer Abdullah and Concat contributors

//! Placing, moving and cutting clips: the edits that change what is on the timeline and when.
//!
//! One arm per command, exactly as [`super::apply`] routes them here;
//! everything these arms share lives in the parent module.

use super::*;

/// Applies one of this module's commands. Any other is a routing error.
pub(super) fn apply(
    project: &mut Project,
    mint: &mut IdMint,
    command: Command,
) -> Result<Outcome, CommandError> {
    match command {
        Command::AddClip {
            media_id,
            track_id,
            start,
            ripple,
        } => {
            let media = project
                .media_by_id(&media_id)
                .ok_or(CommandError::MediaGone)?
                .clone();
            let timeline = project.active_mut();
            if timeline.track(&track_id).is_none() {
                return Err(CommandError::TrackGone);
            }
            // Magnetic, the lane makes room; otherwise the clip takes the
            // nearest gap it fits, never the top of another clip.
            let start = if ripple {
                ripple_room_for(timeline, &track_id, start, &media)
            } else {
                timeline.nearest_free_start(&track_id, start, clip_length(&media), &[])
            };
            let id = mint.next("c");
            timeline
                .clips
                .push(Arc::new(default_clip(id.clone(), track_id, &media, start)));
            Ok(Outcome {
                created_id: Some(id),
                applied: true,
            })
        }

        Command::AddClipAtFirstFree { media_id, start } => {
            let media = project
                .media_by_id(&media_id)
                .ok_or(CommandError::MediaGone)?
                .clone();
            let duration = clip_length(&media);
            let timeline = project.active_mut();
            let track_id = first_free_track(timeline, start, duration)
                .unwrap_or_else(|| fresh_track(timeline, mint));
            let id = mint.next("c");
            timeline
                .clips
                .push(Arc::new(default_clip(id.clone(), track_id, &media, start)));
            Ok(Outcome {
                created_id: Some(id),
                applied: true,
            })
        }

        Command::AddClipsInSequence {
            media_ids,
            track_id,
            start,
            ripple,
        } => {
            let items = media_ids
                .iter()
                .map(|id| {
                    project
                        .media_by_id(id)
                        .cloned()
                        .ok_or(CommandError::MediaGone)
                })
                .collect::<Result<Vec<_>, _>>()?;
            if items.is_empty() {
                return Ok(Outcome {
                    created_id: None,
                    applied: false,
                });
            }
            let start = start.max(0.0);
            let total: f64 = items.iter().map(clip_length).sum();
            let timeline = project.active_mut();
            let track_id = match track_id {
                Some(id) if timeline.track(&id).is_none() => return Err(CommandError::TrackGone),
                Some(id) => id,
                None => first_free_track(timeline, start, total)
                    .unwrap_or_else(|| fresh_track(timeline, mint)),
            };
            let mut at = start;
            let mut first = None;
            for media in &items {
                let place = if ripple {
                    ripple_room_for(timeline, &track_id, at, media)
                } else {
                    timeline.nearest_free_start(&track_id, at, clip_length(media), &[])
                };
                let id = mint.next("c");
                timeline.clips.push(Arc::new(default_clip(
                    id.clone(),
                    track_id.clone(),
                    media,
                    place,
                )));
                first.get_or_insert(id);
                at = place + clip_length(media);
            }
            Ok(Outcome {
                created_id: first,
                applied: true,
            })
        }

        Command::AddTextClip {
            track_id,
            start,
            style,
            duration,
            offset_y,
            above,
        } => {
            let style = style.unwrap_or_default();
            let duration = duration
                .unwrap_or(DEFAULT_TEXT_DURATION)
                .max(MIN_CLIP_DURATION);
            let timeline = project.active_mut();
            let track_id = match track_id {
                Some(id) if timeline.track(&id).is_some() => id,
                Some(_) => return Err(CommandError::TrackGone),
                // Every lane above the video is taken: a new one at the top
                // for the words to land on.
                None if above => first_free_track_above(timeline, start, duration)
                    .unwrap_or_else(|| fresh_track(timeline, mint)),
                None => first_free_track(timeline, start, duration)
                    .unwrap_or_else(|| fresh_track(timeline, mint)),
            };
            let start = timeline.nearest_free_start(&track_id, start, duration, &[]);
            let id = mint.next("c");
            let mut clip = Clip::blank(
                id.clone(),
                track_id,
                ClipKind::Text,
                first_line(&style.content),
                start,
                duration,
            );
            clip.offset_y = offset_y.unwrap_or(0.0).clamp(-MAX_OFFSET, MAX_OFFSET);
            clip.text = Some(style);
            timeline.clips.push(Arc::new(clip));
            Ok(Outcome {
                created_id: Some(id),
                applied: true,
            })
        }

        Command::AddShapeClip {
            track_id,
            above,
            start,
            style,
            duration,
            name,
        } => {
            let style = style.unwrap_or_default().tidy();
            let duration = duration
                .unwrap_or(DEFAULT_TEXT_DURATION)
                .max(MIN_CLIP_DURATION);
            let timeline = project.active_mut();
            let track_id = match track_id {
                Some(id) if timeline.track(&id).is_some() => id,
                Some(_) => return Err(CommandError::TrackGone),
                None if above => first_free_track_above(timeline, start, duration)
                    .unwrap_or_else(|| fresh_track(timeline, mint)),
                None => first_free_track(timeline, start, duration)
                    .unwrap_or_else(|| fresh_track(timeline, mint)),
            };
            let start = timeline.nearest_free_start(&track_id, start, duration, &[]);
            let id = mint.next("c");
            let name = if name.trim().is_empty() {
                style.kind.id().to_owned()
            } else {
                name
            };
            let mut clip =
                Clip::blank(id.clone(), track_id, ClipKind::Shape, name, start, duration);
            clip.shape = Some(style);
            timeline.clips.push(Arc::new(clip));
            Ok(Outcome {
                created_id: Some(id),
                applied: true,
            })
        }

        Command::AddLayerClip {
            track_id,
            start,
            duration,
            effect_id,
            name,
            sound,
        } => {
            let duration = duration
                .unwrap_or(DEFAULT_LAYER_DURATION)
                .max(MIN_CLIP_DURATION);
            let timeline = project.active_mut();
            let track_id = match track_id {
                Some(id) if timeline.track(&id).is_some() => id,
                Some(_) => return Err(CommandError::TrackGone),
                // Over the picture, as a title is: a layer treats what is
                // beneath it, and the bottom-first walk put one under the
                // footage whenever a lower lane was free, where it treated
                // nothing. A sound layer treats every lane alike, and goes
                // over the picture too, where it reads as a treatment and
                // not as one more sound.
                None => first_free_track_above(timeline, start, duration)
                    .unwrap_or_else(|| fresh_track(timeline, mint)),
            };
            let start = timeline.nearest_free_start(&track_id, start, duration, &[]);
            let id = mint.next("c");
            let name = if name.trim().is_empty() {
                effect_id.clone()
            } else {
                name
            };
            let kind = if sound {
                ClipKind::SoundLayer
            } else {
                ClipKind::Layer
            };
            let mut clip = Clip::blank(id.clone(), track_id, kind, name, start, duration);
            if sound {
                clip.filters = vec![AppliedFilter::new(effect_id)];
            } else {
                clip.video_effects = vec![AppliedFilter::new(effect_id)];
            }
            timeline.clips.push(Arc::new(clip));
            Ok(Outcome {
                created_id: Some(id),
                applied: true,
            })
        }

        Command::MoveClips { moves } => {
            let timeline = project.active_mut();
            // Onto another clip is never where a move lands: the group goes
            // to the nearest gap that holds it, and a move whose own clips
            // would cover each other stays where it was.
            let Some(moves) = timeline.resolve_moves(&moves) else {
                return Ok(Outcome::default());
            };
            let mut applied = false;
            for wanted in moves {
                if let Some(clip) = timeline.clip_mut(&wanted.clip_id) {
                    applied |= assign(&mut clip.start, wanted.start);
                    applied |= assign(&mut clip.track_id, wanted.track_id);
                }
            }
            Ok(Outcome {
                created_id: None,
                applied,
            })
        }

        Command::TrimClip {
            clip_id,
            edge,
            delta,
            ripple,
        } => {
            let timeline = project.active_mut();
            let Some(clip) = timeline.clip_mut(&clip_id) else {
                return Ok(Outcome::default());
            };
            let track_id = clip.track_id.clone();
            let anchor = clip.start;
            let old_end = clip.start + clip.duration;
            // A plain trim stops at the neighbours; a magnetic one moves
            // them instead, so it has the lane's whole length.
            let (floor, ceiling) = if ripple {
                (0.0, f64::INFINITY)
            } else {
                let (before, after) = timeline
                    .room_around(&clip_id)
                    .unwrap_or((0.0, f64::INFINITY));
                (before, after)
            };
            let Some(clip) = timeline.clip_mut(&clip_id) else {
                return Ok(Outcome::default());
            };
            // What the trim did, and what the lane behind it does about
            // it when it is magnetic: `by` is how far the later clips
            // move, `behind` where "later" begins.
            let (applied, by, behind) = match edge {
                TrimEdge::End => {
                    let duration = (clip.duration + delta)
                        .min(ceiling - clip.start)
                        .max(MIN_CLIP_DURATION);
                    let old = clip.duration;
                    let applied = assign(&mut clip.duration, duration);
                    if applied {
                        clip.rewindow_keys(old, 0.0, duration);
                        crate::speed::rewindow_clip(clip, old, 0.0, duration);
                    }
                    (applied, duration - old, old_end - JOIN_EPSILON)
                }
                TrimEdge::Start => {
                    // Dragging the head moves the in-point too, so the pixels
                    // under the remaining part of the clip do not slide. The
                    // head cannot reach before the source begins.
                    // Under a curve the head extends at the speed it starts at.
                    let lead = clip
                        .speed_curve
                        .as_deref()
                        .and_then(crate::speed::curve_of)
                        .map_or(clip.speed, |curve| curve.speed_at(0.0));
                    let shift = delta
                        .min(clip.duration - MIN_CLIP_DURATION)
                        .max(-clip.source_start / lead);
                    // A magnetic head trim never moves the clip, so the
                    // timeline's own start is no limit to it; a plain one
                    // stops at zero.
                    let start = if ripple {
                        clip.start + shift
                    } else {
                        (clip.start + shift).max(floor)
                    };
                    let moved = start - clip.start;
                    let duration = clip.duration - moved;
                    let old = clip.duration;
                    // The source the head took with it: a constant rate's
                    // share, or under a curve the curve's own. Worked on a
                    // copy, so a trim that changes nothing changes nothing.
                    let mut retimed = Clip::clone(clip);
                    let consumed = crate::speed::rewindow_clip(&mut retimed, old, moved, old)
                        .unwrap_or(moved * clip.speed);
                    let source_start = (clip.source_start + consumed).max(0.0);
                    // Bitwise so no assignment is short-circuited away.
                    let applied = assign(&mut clip.start, start)
                        | assign(&mut clip.duration, duration)
                        | assign(&mut clip.source_start, source_start);
                    if applied {
                        clip.rewindow_keys(old, moved, old);
                        clip.speed = retimed.speed;
                        clip.speed_curve = retimed.speed_curve;
                    }
                    if ripple {
                        // The in-point moved; the clip stays put, and the
                        // lane behind it closes by what came off the head.
                        clip.start = anchor;
                    }
                    (applied, -moved, anchor + JOIN_EPSILON)
                }
            };
            if ripple && applied && by != 0.0 {
                for other in timeline.clips_where(|other| {
                    other.id != clip_id && other.track_id == track_id && other.start >= behind
                }) {
                    other.start = (other.start + by).max(0.0);
                }
            }
            Ok(Outcome {
                created_id: None,
                applied,
            })
        }

        Command::SplitClips { clip_ids, time } => {
            let timeline = project.active_mut();
            let mut created = None;
            for clip_id in clip_ids {
                let Some(index) = timeline.clips.iter().position(|clip| clip.id == clip_id) else {
                    continue;
                };
                let clip: &Clip = &timeline.clips[index];
                let offset = time - clip.start;
                if offset <= MIN_CLIP_DURATION || offset >= clip.duration - MIN_CLIP_DURATION {
                    continue;
                }
                let (head_source, mut tail_source) =
                    split_source(clip.source_start, clip.speed, offset);
                let whole = clip.duration;
                let mut tail = clip.clone();
                // Under a curve each half keeps its share of it, and the
                // tail starts where the curve had got to in the source.
                if let Some(consumed) = crate::speed::rewindow_clip(&mut tail, whole, offset, whole)
                {
                    tail_source = clip.source_start + consumed;
                }
                tail.id = mint.next("c");
                tail.start = clip.start + offset;
                tail.duration = clip.duration - offset;
                tail.source_start = tail_source;
                // The transition belongs to the cut at the original clip's
                // start, which the head keeps; the way in belongs to the
                // head and the way out to the tail, so neither piece plays
                // an entrance or an exit the whole did not have at the cut.
                tail.transition_in = None;
                tail.fade_in = 0.0;
                tail.rewindow_keys(whole, offset, whole);
                created = Some(tail.id.clone());
                let head = timeline.clip_at_mut(index);
                crate::speed::rewindow_clip(head, whole, 0.0, offset);
                head.duration = offset;
                head.source_start = head_source;
                head.fade_out = 0.0;
                head.rewindow_keys(whole, 0.0, offset);
                timeline.clips.insert(index + 1, Arc::new(tail));
            }
            // A split always mints the tail, so "minted anything" and
            // "changed anything" are the same fact here.
            let applied = created.is_some();
            Ok(Outcome {
                created_id: created,
                applied,
            })
        }

        Command::ReplaceClipMedia {
            clip_id,
            item,
            source_start,
            enhanced,
        } => {
            if project.active().clip(&clip_id).is_none() {
                return Ok(Outcome::default());
            }
            // The copy's bin entry, or the one already there for its path:
            // two clips of one file enhanced in turn share one copy.
            let media_id = match project.media.iter().find(|media| media.path == item.path) {
                Some(existing) => existing.id.clone(),
                None => {
                    let id = mint.next("m");
                    project.media.push(MediaItem {
                        id: id.clone(),
                        path: item.path,
                        name: item.name,
                        duration: item.duration,
                        kind: item.kind,
                        width: item.width,
                        height: item.height,
                        frame_rate: item.frame_rate,
                        frame_rate_fraction: item.frame_rate_fraction,
                        video_codec: item.video_codec,
                        audio_codec: item.audio_codec,
                        has_audio: item.has_audio,
                        audio_tracks: item.audio_tracks,
                        origin: item.origin,
                        placeholder: false,
                        color_range: None,
                        color_space: item.color_space,
                        extra: Default::default(),
                    });
                    id
                }
            };
            let timeline = project.active_mut();
            let Some(index) = timeline.clips.iter().position(|clip| clip.id == clip_id) else {
                return Ok(Outcome::default());
            };
            let clip = timeline.clip_at_mut(index);
            let link = if enhanced {
                // The original is the one Enhance started from, kept through
                // a second run on a clip already showing a copy.
                let original = clip
                    .enhanced
                    .as_ref()
                    .map(|link| link.original.clone())
                    .unwrap_or_else(|| clip.media_id.clone());
                Some(Enhanced {
                    original,
                    copy: media_id.clone(),
                    on: true,
                })
            } else {
                None
            };
            // Bitwise so no assignment is short-circuited away.
            let applied = assign(&mut clip.media_id, media_id.clone())
                | source_start.is_some_and(|start| assign(&mut clip.source_start, start.max(0.0)))
                | assign(&mut clip.enhanced, link);
            if !applied {
                return Ok(Outcome::default());
            }
            Ok(Outcome {
                created_id: Some(media_id),
                applied: true,
            })
        }

        Command::SetClipEnhanced { clip_id, on } => {
            let timeline = project.active_mut();
            let Some(index) = timeline.clips.iter().position(|clip| clip.id == clip_id) else {
                return Ok(Outcome::default());
            };
            let Some(link) = timeline.clips[index].enhanced.clone() else {
                return Ok(Outcome::default());
            };
            let clip = timeline.clip_at_mut(index);
            let media = if on {
                link.copy.clone()
            } else {
                link.original.clone()
            };
            let applied = assign(&mut clip.media_id, media)
                | assign(&mut clip.enhanced, Some(Enhanced { on, ..link }));
            Ok(Outcome {
                created_id: None,
                applied,
            })
        }

        Command::FreezeFrame {
            clip_id,
            time,
            duration,
            still,
        } => {
            let hold = duration
                .filter(|value| *value > 0.0)
                .unwrap_or(DEFAULT_FREEZE_DURATION)
                .max(MIN_CLIP_DURATION);

            let (kind, media_id, track_id, start, clip_duration, speed, source_start, picture) = {
                let timeline = project.active();
                let Some(clip) = timeline.clip(&clip_id) else {
                    return Ok(Outcome::default());
                };
                if clip.kind != ClipKind::Video && clip.kind != ClipKind::Image {
                    return Ok(Outcome::default());
                }
                let offset = time - clip.start;
                if offset <= MIN_CLIP_DURATION || offset >= clip.duration - MIN_CLIP_DURATION {
                    return Ok(Outcome::default());
                }
                (
                    clip.kind,
                    clip.media_id.clone(),
                    clip.track_id.clone(),
                    clip.start,
                    clip.duration,
                    clip.speed,
                    clip.source_start,
                    clip.clone(),
                )
            };

            let freeze_media_id = if kind == ClipKind::Image && still.is_none() {
                media_id
            } else {
                let Some(item) = still else {
                    return Ok(Outcome::default());
                };
                if let Some(existing) = project.media.iter().find(|media| media.path == item.path) {
                    existing.id.clone()
                } else {
                    let id = mint.next("m");
                    project.media.push(MediaItem {
                        id: id.clone(),
                        path: item.path,
                        name: item.name,
                        duration: item.duration,
                        kind: MediaKind::Image,
                        width: item.width,
                        height: item.height,
                        frame_rate: item.frame_rate,
                        frame_rate_fraction: item.frame_rate_fraction,
                        video_codec: item.video_codec,
                        audio_codec: None,
                        has_audio: false,
                        audio_tracks: Vec::new(),
                        origin: item.origin,
                        placeholder: false,
                        color_range: None,
                        color_space: item.color_space,
                        extra: Default::default(),
                    });
                    id
                }
            };

            let timeline = project.active_mut();
            let Some(index) = timeline.clips.iter().position(|clip| clip.id == clip_id) else {
                return Ok(Outcome::default());
            };
            // The cut is a split's, so it leaves the pieces as a split does:
            // under a curve each keeps its share of it.
            let offset = time - start;
            let (head_source, mut tail_source) = split_source(source_start, speed, offset);
            let mut tail = Clip::clone(&timeline.clips[index]);
            if let Some(consumed) =
                crate::speed::rewindow_clip(&mut tail, clip_duration, offset, clip_duration)
            {
                tail_source = source_start + consumed;
            }
            tail.id = mint.next("c");
            tail.start = time;
            tail.duration = clip_duration - offset;
            tail.source_start = tail_source;
            tail.transition_in = None;
            tail.fade_in = 0.0;
            tail.rewindow_keys(clip_duration, offset, clip_duration);
            let head = timeline.clip_at_mut(index);
            crate::speed::rewindow_clip(head, clip_duration, 0.0, offset);
            head.duration = offset;
            head.source_start = head_source;
            head.fade_out = 0.0;
            head.rewindow_keys(clip_duration, 0.0, offset);
            timeline.clips.insert(index + 1, Arc::new(tail));

            // Ripple every later placement on this track (including the new
            // tail) so the freeze does not sit on top of the remainder.
            for clip in timeline.clips_where(|clip| clip.track_id == track_id && clip.start >= time)
            {
                clip.start += hold;
            }

            // The still is the source clip turned into a picture: cloning it
            // first carries every look field - transform, effects, crop,
            // flips, whatever the model grows - and then the hold's own
            // facts overwrite the moving ones.
            let freeze_id = mint.next("c");
            let mut frozen = picture;
            frozen.id = freeze_id.clone();
            frozen.track_id = track_id;
            frozen.kind = ClipKind::Image;
            frozen.media_id = freeze_media_id;
            frozen.start = time;
            frozen.duration = hold;
            frozen.source_start = 0.0;
            frozen.speed = 1.0;
            frozen.speed_curve = None;
            frozen.volume = 1.0;
            frozen.fade_in = 0.0;
            frozen.fade_out = 0.0;
            frozen.filters = Vec::new();
            frozen.muted = None;
            frozen.detached_from = None;
            frozen.transition_in = None;
            frozen.text = None;
            timeline.clips.push(Arc::new(frozen));

            Ok(Outcome {
                created_id: Some(freeze_id),
                applied: true,
            })
        }

        Command::MergeClips { clip_ids } => {
            let timeline = project.active_mut();
            if let Some(reason) = why_not_merge(timeline, &clip_ids) {
                return Err(CommandError::CannotMerge { reason });
            }
            let mut ordered: Vec<Clip> = clip_ids
                .iter()
                .filter_map(|id| timeline.clip(id).cloned())
                .collect();
            ordered.sort_by(|left, right| left.start.total_cmp(&right.start));
            let first = ordered.first().expect("validated above").clone();
            let last = ordered.last().expect("validated above");
            let merged_duration = last.start + last.duration - first.start;

            // A set, not a Vec: the retain below tests every clip on the
            // timeline against it.
            let doomed: HashSet<String> =
                ordered.iter().skip(1).map(|clip| clip.id.clone()).collect();
            timeline.clips.retain(|clip| !doomed.contains(&clip.id));
            let survivor = timeline
                .clip_mut(&first.id)
                .expect("the first piece survives the retain");
            survivor.duration = merged_duration;
            // Every piece's keys land where they were on the picture; the
            // way out is the last piece's, as the way in is the first's.
            survivor.rewindow_keys(first.duration, 0.0, merged_duration);
            for piece in ordered.iter().skip(1) {
                survivor.absorb_keys(piece, piece.start - first.start);
            }
            survivor.fade_out = last.fade_out;
            // A validated merge always absorbs at least one piece.
            Ok(Outcome {
                created_id: Some(first.id),
                applied: true,
            })
        }

        Command::ConsolidateClips { clip_ids, item } => {
            let clips = consolidation_clips(project.active(), &clip_ids)?;
            let first = &clips[0];
            let end = clips
                .iter()
                .map(|clip| clip.start + clip.duration)
                .fold(0.0, f64::max);
            let duration = end - first.start;
            if item.kind != MediaKind::Video
                || item.path.is_empty()
                || item.duration.is_none_or(|length| length + 1e-6 < duration)
            {
                return Err(CommandError::CannotMerge {
                    reason: "The merged video does not cover the selected clips.".into(),
                });
            }
            let path = item.path.clone();
            super::media::apply(project, mint, Command::AddMedia { item })?;
            let media = project
                .media
                .iter()
                .find(|media| super::media::same_path(&media.path, &path))
                .expect("imported above");
            let mut merged =
                default_clip(first.id.clone(), first.track_id.clone(), media, first.start);
            merged.duration = duration;
            let timeline = project.active_mut();
            let selected: HashSet<_> = clip_ids.iter().collect();
            timeline.clips.retain(|clip| !selected.contains(&clip.id));
            timeline.clips.push(Arc::new(merged));
            Ok(Outcome {
                created_id: Some(first.id.clone()),
                applied: true,
            })
        }

        Command::RemoveClips { clip_ids, ripple } => {
            let timeline = project.active_mut();
            let doomed: HashSet<&str> = clip_ids.iter().map(String::as_str).collect();
            // The spans going, per track, taken before they are gone: the
            // ripple closes exactly these.
            let removed: Vec<(String, f64, f64)> = timeline
                .clips
                .iter()
                .filter(|clip| doomed.contains(clip.id.as_str()))
                .map(|clip| {
                    (
                        clip.track_id.clone(),
                        clip.start,
                        clip.start + clip.duration,
                    )
                })
                .collect();
            let clip_count = timeline.clips.len();
            timeline
                .clips
                .retain(|clip| !doomed.contains(clip.id.as_str()));
            let applied = timeline.clips.len() != clip_count;
            if ripple && applied {
                close_gaps(timeline, &removed);
            }
            Ok(Outcome {
                created_id: None,
                applied,
            })
        }

        _ => unreachable!("commands::apply routes only this module's commands here"),
    }
}

/// How far apart two clips may sit and still count as touching, in seconds.
const JOIN_EPSILON: f64 = 1e-6;

/// The ripple of a delete: pulls every clip that sits after a removed
/// span left by the length of the removed spans before it, on that clip's
/// own track. Spans that overlap count once - a clip behind two doomed
/// clips that shared five seconds moves by their union, not their sum, or
/// it would land in front of what was in front of it. A span reaching past
/// the clip's start counts only up to it, and nothing is pulled before
/// zero.
/// https://github.com/jub0t/Concat/issues/106
fn close_gaps(timeline: &mut Timeline, removed: &[(String, f64, f64)]) {
    let behind_a_span = |clip: &Clip| {
        removed
            .iter()
            .any(|(track, start, _)| *track == clip.track_id && *start < clip.start)
    };
    for clip in timeline.clips_where(behind_a_span) {
        let mut spans: Vec<(f64, f64)> = removed
            .iter()
            .filter(|(track, start, _)| *track == clip.track_id && *start < clip.start)
            .map(|(_, start, end)| (*start, end.min(clip.start)))
            .collect();
        if spans.is_empty() {
            continue;
        }
        spans.sort_by(|a, b| a.0.total_cmp(&b.0));
        let mut gap = 0.0;
        let (mut from, mut to) = spans[0];
        for (start, end) in spans.into_iter().skip(1) {
            if start <= to {
                to = to.max(end);
            } else {
                gap += to - from;
                from = start;
                to = end;
            }
        }
        gap += to - from;
        clip.start = (clip.start - gap).max(0.0);
    }
}

fn default_clip(id: String, track_id: String, media: &MediaItem, start: f64) -> Clip {
    let kind = match media.kind {
        MediaKind::Video => ClipKind::Video,
        MediaKind::Audio => ClipKind::Audio,
        MediaKind::Image => ClipKind::Image,
    };
    let mut clip = Clip::blank(
        id,
        track_id,
        kind,
        media.name.clone(),
        start,
        clip_length(media),
    );
    clip.media_id = media.id.clone();
    clip
}

/// Makes room on `track_id` for a new clip at `start`: a drop onto the
/// middle of a clip lands at that clip's end instead, and every clip at
/// or after the place it lands moves right by the new clip's length, so
/// the new clip slots in and nothing is covered (#129). Returns where the
/// new clip lands. A drop with room to spare changes nothing.
fn ripple_room_for(timeline: &mut Timeline, track_id: &str, start: f64, media: &MediaItem) -> f64 {
    let duration = clip_length(media);
    // Dropped onto a clip: after it, rather than over it or through it.
    let start = timeline
        .clips
        .iter()
        .filter(|clip| {
            clip.track_id == track_id && clip.start < start && start < clip.start + clip.duration
        })
        .map(|clip| clip.start + clip.duration)
        .fold(start, f64::max);
    let end = start + duration;
    let overlaps = timeline.clips.iter().any(|clip| {
        clip.track_id == track_id && clip.start < end && start < clip.start + clip.duration
    });
    if !overlaps {
        return start;
    }
    for clip in timeline.clips_where(|clip| clip.track_id == track_id && clip.start >= start) {
        clip.start += duration;
    }
    start
}

/// How long a new clip of `media` is: a still's default hold, or the
/// file's own length.
fn clip_length(media: &MediaItem) -> f64 {
    match media.kind {
        MediaKind::Image => DEFAULT_IMAGE_DURATION,
        _ => media.duration.unwrap_or(UNKNOWN_DURATION),
    }
}

/// The lowest track with nothing occupying `[start, start + duration)`.
/// `None` when every lane is taken there: the caller opens a new one
/// rather than covering a clip.
fn first_free_track(timeline: &Timeline, start: f64, duration: f64) -> Option<String> {
    timeline
        .tracks
        .iter()
        .find(|track| timeline.is_free(&track.id, start, duration, &[]))
        .map(|track| track.id.clone())
}

/// A new, empty lane at the top, for a clip with nowhere else to go.
fn fresh_track(timeline: &mut Timeline, mint: &mut IdMint) -> String {
    let id = mint.next("t");
    timeline.tracks.push(Track {
        id: id.clone(),
        visible: true,
        muted: false,
        extra: Default::default(),
    });
    id
}

/// First free lane *above* the highest one occupied over `[start, start +
/// duration)`. `None` when every lane above is taken, which is the caller's
/// cue to mint a new one at the top.
///
/// Captions and titles go through this so they sit over the video, not
/// under it. The plain `first_free_track` still walks from the bottom,
/// which is what a sound or a picture wants.
fn first_free_track_above(timeline: &Timeline, start: f64, duration: f64) -> Option<String> {
    let end = start + duration;
    let occupied = |track_id: &str| {
        timeline.clips.iter().any(|clip| {
            clip.track_id == track_id && clip.start < end && start < clip.start + clip.duration
        })
    };
    let floor = timeline
        .tracks
        .iter()
        .enumerate()
        .filter(|(_, track)| occupied(&track.id))
        .map(|(row, _)| row + 1)
        .max()
        .unwrap_or(0);
    timeline
        .tracks
        .iter()
        .skip(floor)
        .find(|track| !occupied(&track.id))
        .map(|track| track.id.clone())
}

/// Which side of the playhead [`delete_to_playhead`] takes away.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum PlayheadSide {
    /// From the clip's start up to the playhead: CapCut's Delete Left (Q).
    Left,
    /// From the playhead to the clip's end: CapCut's Delete Right (W).
    Right,
}

/// Delete Left / Delete Right: each named clip that `at` runs through loses
/// what lies on `side` of it, as trims of the edge on that side brought to
/// `at` - so a head cut keeps the frames after the playhead where they
/// were in the source. More than one clip is one [`Command::Batch`], one
/// undo step. `ripple` closes each lane behind the cut, as a trim on the
/// magnetic timeline does.
///
/// A clip the instant misses, or grazes within [`MIN_CLIP_DURATION`] of an
/// end, is skipped, the way [`Command::SplitClips`] skips it: there is
/// nothing to take. So is a second clip on a lane that already has one:
/// a magnetic cut moves what comes after it, and the second clip's cut
/// was measured before that move. None when nothing is left to cut.
pub fn delete_to_playhead(
    timeline: &Timeline,
    clip_ids: &[String],
    at: f64,
    side: PlayheadSide,
    ripple: bool,
) -> Option<Command> {
    let mut lanes = HashSet::new();
    let mut trims: Vec<Command> = clip_ids
        .iter()
        .filter_map(|id| timeline.clip(id))
        .filter(|clip| {
            clip.start + MIN_CLIP_DURATION < at
                && at < clip.start + clip.duration - MIN_CLIP_DURATION
        })
        .filter(|clip| lanes.insert(clip.track_id.clone()))
        .map(|clip| {
            let (edge, delta) = match side {
                PlayheadSide::Left => (TrimEdge::Start, at - clip.start),
                PlayheadSide::Right => (TrimEdge::End, at - (clip.start + clip.duration)),
            };
            Command::TrimClip {
                clip_id: clip.id.clone(),
                edge,
                delta,
                ripple,
            }
        })
        .collect();
    match trims.len() {
        0 => None,
        1 => trims.pop(),
        _ => Some(Command::Batch { commands: trims }),
    }
}

/// Where each piece of a clip cut at `offset` begins in the source: the
/// head keeps its in-point and the tail starts `offset × speed` later, so
/// the two pieces together show exactly what the whole did.
fn split_source(source_start: f64, speed: f64, offset: f64) -> (f64, f64) {
    (source_start, source_start + offset * speed)
}

/// Why these clips cannot be merged, or None if they can. A sentence, because
/// a disabled button that will not say why is worse than no button.
pub fn why_not_merge(timeline: &Timeline, clip_ids: &[String]) -> Option<String> {
    if clip_ids.len() < 2 {
        return Some("Select two or more clips to merge.".to_owned());
    }
    let clips: Vec<&Clip> = clip_ids.iter().filter_map(|id| timeline.clip(id)).collect();
    if clips.len() < 2 {
        return Some("Select two or more clips to merge.".to_owned());
    }
    if clips.iter().any(|clip| clip.track_id != clips[0].track_id) {
        return Some("Merged clips must be on the same track.".to_owned());
    }
    if clips.iter().any(|clip| clip.media_id != clips[0].media_id) {
        return Some("Merged clips must come from the same file.".to_owned());
    }
    if clips.iter().any(|clip| clip.speed != clips[0].speed) {
        return Some("Merged clips must play at the same speed.".to_owned());
    }
    if clips.iter().any(|clip| clip.kind != clips[0].kind) {
        return Some("Merged clips must be the same kind.".to_owned());
    }
    if clips.iter().any(|clip| clip.speed_curve.is_some()) {
        return Some("A clip with a speed curve cannot be merged.".to_owned());
    }
    if clips
        .iter()
        .any(|clip| clip.audio_stream != clips[0].audio_stream)
    {
        return Some("Merged clips must play the same audio track.".to_owned());
    }

    let mut ordered = clips.clone();
    ordered.sort_by(|left, right| left.start.total_cmp(&right.start));
    for pair in ordered.windows(2) {
        let (previous, current) = (pair[0], pair[1]);
        if (current.start - (previous.start + previous.duration)).abs() > JOIN_EPSILON {
            return Some("Merged clips must touch, with no gap or overlap.".to_owned());
        }
        // The next piece starts where the last one's source ended.
        let continuous =
            current.source_start - (previous.source_start + previous.duration * previous.speed);
        if continuous.abs() > JOIN_EPSILON {
            return Some("These pieces are no longer in their original order.".to_owned());
        }
    }
    None
}

/// Validates a selection for rendering into one clip, in timeline order.
/// Gaps remain in the render. Unselected clips in its span are refused so
/// the replacement cannot cover them. Source order and file need not match.
pub fn consolidation_clips(
    timeline: &Timeline,
    clip_ids: &[String],
) -> Result<Vec<Clip>, CommandError> {
    let refuse = |reason: &str| CommandError::CannotMerge {
        reason: reason.into(),
    };
    let selected: HashSet<_> = clip_ids.iter().collect();
    if selected.len() < 2 || selected.len() != clip_ids.len() {
        return Err(refuse("Select two or more distinct video clips to merge."));
    }
    let mut clips: Vec<Clip> = clip_ids
        .iter()
        .map(|id| {
            timeline
                .clip(id)
                .cloned()
                .ok_or_else(|| refuse("A selected clip no longer exists."))
        })
        .collect::<Result<_, _>>()?;
    clips.sort_by(|a, b| a.start.total_cmp(&b.start));
    let first = &clips[0];
    if clips
        .iter()
        .any(|clip| clip.kind != ClipKind::Video || clip.track_id != first.track_id)
    {
        return Err(refuse("Select video clips on the same track to merge."));
    }
    if timeline.track(&first.track_id).is_none() {
        return Err(CommandError::TrackGone);
    }
    if clips
        .windows(2)
        .any(|pair| pair[1].start < pair[0].start + pair[0].duration - 1e-6)
    {
        return Err(refuse("Overlapping clips cannot be merged."));
    }
    if timeline.clips.iter().any(|clip| {
        clip.detached_from
            .as_ref()
            .is_some_and(|id| selected.contains(id))
    }) {
        return Err(refuse(
            "Reattach detached audio before merging its video clips.",
        ));
    }
    let end = clips
        .iter()
        .map(|clip| clip.start + clip.duration)
        .fold(0.0, f64::max);
    if timeline.clips.iter().any(|clip| {
        clip.track_id == first.track_id
            && !selected.contains(&clip.id)
            && clip.start < end - 1e-6
            && clip.start + clip.duration > first.start + 1e-6
    }) {
        return Err(refuse("Select every clip inside the span to merge."));
    }
    // Rounding several subframe spans is not always equivalent to rounding
    // their union. Refuse a span that one ordinary clip could truncate, or
    // whose pieces overlap after quantisation, instead of losing a frame.
    let fps = timeline.video.rate();
    let frame = |seconds: f64| (seconds * fps).round();
    let rendered_end = clips
        .iter()
        .map(|clip| frame(clip.start) + frame(clip.duration))
        .fold(0.0, f64::max);
    if rendered_end != frame(first.start) + frame(end - first.start)
        || clips
            .windows(2)
            .any(|pair| frame(pair[1].start) < frame(pair[0].start) + frame(pair[0].duration))
    {
        return Err(refuse(
            "Align clip boundaries to the timeline frame grid before merging.",
        ));
    }
    // MP4 bakes against black and cannot carry the selection's alpha.
    // Refuse a bake that would cover an existing lower-track composite.
    let lane = timeline
        .tracks
        .iter()
        .position(|track| track.id == first.track_id)
        .expect("checked above");
    if timeline.clips.iter().any(|clip| {
        clip.kind != ClipKind::Audio
            && clip.start < end
            && clip.start + clip.duration > first.start
            && timeline
                .tracks
                .iter()
                .take(lane)
                .any(|track| track.id == clip.track_id && track.visible)
    }) {
        return Err(refuse(
            "Clips above other visible content cannot be merged into an opaque video.",
        ));
    }
    // An edge transition needs footage outside the selected span. Internal
    // transitions are rendered normally; never silently bake only half one.
    if first.transition_in.is_some()
        || timeline.clips.iter().any(|clip| {
            clip.track_id == first.track_id
                && !selected.contains(&clip.id)
                && (clip.start - end).abs() < 1e-6
                && clip.transition_in.is_some()
        })
    {
        return Err(refuse("Include both sides of a transition in the merge."));
    }
    Ok(clips)
}
